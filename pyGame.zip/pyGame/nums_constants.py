MENU_PLAY = 0
MENU_MAIN = 1
MENU_WIN = 2
MENU_LOSE = 3
DEFAULT_X = 200
DEFAULT_Y = 245

background_x = 0

enemy_speed = 5

score_to_ins = 0
nickname = 'name'

running = True
